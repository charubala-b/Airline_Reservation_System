package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class seatsController {

    @FXML
    private Button enter;

    @FXML
    private Label noofseats;

    @FXML
    private Label seatcancellation;

    @FXML
    private Label seatno;

    @FXML
    private Label seatspecification;

    @FXML
    void seatsconfirmation(ActionEvent event) {

    }

}
