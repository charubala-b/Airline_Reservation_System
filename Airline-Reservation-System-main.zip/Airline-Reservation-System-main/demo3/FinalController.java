package com.example.demo3;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class FinalController {

    @FXML
    private AnchorPane conformation;

    @FXML
    private AnchorPane conformation1;

    @FXML
    private Button ok;

    @FXML
    private Button ok1;

    @FXML
    private Label sucess;

    @FXML
    private Label sucess1;

    @FXML
    private Label travel;

    @FXML
    private Label travel1;

}
