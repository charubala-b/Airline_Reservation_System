package com.example.demo3;

public class SortedList<T> {
    public SortedList(SortedList<T> sortedData) {

    }
}
